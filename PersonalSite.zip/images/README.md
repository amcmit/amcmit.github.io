# Images for Alex Carroll's Personal Site

Save your images to this folder with the following names:

1. **me.png** - Your professional headshot (navy suit, blue background)
2. **presenting-1.png** - Presenting "Three Approaches" slide
3. **presenting-2.png** - Presenting "Agentic Orchestration for Supplier Intelligence"  
4. **team.png** - Group photo with 5 colleagues
5. **roundtable-1.png** - Classroom/audience shot (you're sitting in front)
6. **roundtable-2.png** - Table 7 working session
7. **group.png** - Large conference group photo

All images should be in PNG or JPG format.



